-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2017 at 11:04 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `wpminiproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `addproject`
--

CREATE TABLE IF NOT EXISTS `addproject` (
  `projecttitle` varchar(20) NOT NULL,
  `projectabstract` varchar(200) NOT NULL,
  `reference1` varchar(30) NOT NULL,
  `reference2` varchar(30) NOT NULL,
  `reference3` varchar(30) NOT NULL,
  `reference4` varchar(30) NOT NULL,
  `Department` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addproject`
--

INSERT INTO `addproject` (`projecttitle`, `projectabstract`, `reference1`, `reference2`, `reference3`, `reference4`, `Department`) VALUES
('ffdd', 'fffff', 'fdfdf', 'fbjefmle,flerkehfje', 'kehfjefklefkgbrgjklr', 'dfghj', 'IT Department'),
('Google Glass', 'Google Glass is an optical head-mounted display designed in the shape of a pair of eyeglasses. It was developed by X (previously Google X)[9] with the mission of producing a ubiquitous computer.[1] Go', 'google.com', 'https://en.wikipedia.org/wiki/', '', '', 'IT Department');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
