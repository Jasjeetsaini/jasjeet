function myFunction() {



var a = document.forms["addproject"]["projecttitle"];
   if (a.value == "") {
       alert("Please Enter Project Title");
       return false;
         }

         var b = document.forms["addproject"]["projectabstract"];
            if (b.value == "") {
                alert("Please Enter Project Abstract");
                return false;
                  }

                  var d= document.forms["addproject"]["Department"];

                  	if (Departmentselect(d)) {
                  		 alert('Please Select Department');
                        return false;
                  	}
                }
                function Departmentselect(Department)
                				{

                					if(Department.value == "no")
                					{
                						 alert('Select Department');
                						return false;
                					}

                				}
